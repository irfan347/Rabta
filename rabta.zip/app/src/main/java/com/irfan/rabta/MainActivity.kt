package com.irfan.rabta

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.nearby.connection.Payload

class MainActivity : Activity(), Router.UiListener {

    private data class Pal(
        val bg: Int, val card: Int, val stroke: Int, val field: Int, val text: Int, val sub: Int,
        val green: Int, val greenSoft: Int, val blue: Int, val blueSoft: Int, val red: Int, val onFill: Int, val bubble: Int
    )
    private fun c(v: Long) = v.toInt()
    private val pal by lazy {
        val dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        if (dark) Pal(c(0xFF0F1115), c(0xFF1A1D23), c(0xFF2A2E36), c(0xFF22262D), c(0xFFECEEF1), c(0xFF9AA1AC),
            c(0xFF81C995), c(0xFF1E3326), c(0xFF8AB4F8), c(0xFF1C2A40), c(0xFFF28B82), c(0xFF0F1115), c(0xFF144D2E))
        else Pal(c(0xFFF4F5F7), c(0xFFFFFFFF), c(0xFFE3E5E8), c(0xFFF7F8FA), c(0xFF16181D), c(0xFF6B7280),
            c(0xFF0F9D58), c(0xFFE6F4EA), c(0xFF1A73E8), c(0xFFE8F0FE), c(0xFFD93025), c(0xFFFFFFFF), c(0xFFDCF8C6))
    }
    private val isDark by lazy { (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES }

    private lateinit var router: Router
    private var voice: VoiceCall? = null
    private val handler = Handler(Looper.getMainLooper())
    private var started = false

    private lateinit var statusText: TextView
    private lateinit var startBtn: TextView
    private lateinit var peopleList: LinearLayout
    private lateinit var chatBox: LinearLayout
    private lateinit var chatScroll: ScrollView
    private lateinit var input: EditText
    private lateinit var nameInput: EditText

    private val PICK_FILE = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        router = Router(this, this)
        buildUi()
        ensurePermissions()
    }

    override fun onDestroy() { if (started) router.stop(); voice?.stop(); super.onDestroy() }

    private fun prefs() = getSharedPreferences("rabta", MODE_PRIVATE)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun round(color: Int, r: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat(); if (stroke != null) setStroke(dp(1), stroke)
    }
    private fun ripple(r: Int) = RippleDrawable(
        ColorStateList.valueOf(if (isDark) 0x33FFFFFF else 0x22000000), null, round(0xFF000000.toInt(), r))
    private fun tv(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun lp(top: Int = 0, bottom: Int = 0) =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(top); bottomMargin = dp(bottom) }
    private fun button(label: String, color: Int, filled: Boolean, onClick: () -> Unit) = tv(label, 15f, if (filled) pal.onFill else color, true).apply {
        gravity = Gravity.CENTER; setPadding(dp(16), dp(13), dp(16), dp(13))
        background = if (filled) round(color, 14) else round(pal.card, 14, pal.stroke)
        foreground = ripple(14); isClickable = true; setOnClickListener { onClick() }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(pal.bg) }
        setContentView(root)

        // Header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(18), dp(16), dp(14))
            setBackgroundColor(pal.card)
        }
        header.addView(tv("Rabta", 24f, pal.text, true))
        header.addView(tv("Chat, files and calls with no internet", 13f, pal.sub))
        nameInput = EditText(this).apply {
            hint = "Your name"; textSize = 15f; setTextColor(pal.text); setHintTextColor(pal.sub); setSingleLine(true)
            background = round(pal.field, 12, pal.stroke); setPadding(dp(14), dp(10), dp(14), dp(10))
            setText(prefs().getString("name", Build.MODEL ?: "My phone"))
        }
        header.addView(nameInput, lp(top = 12))
        startBtn = button("Go online", pal.green, filled = true) { toggle() }
        header.addView(startBtn, lp(top = 10))
        statusText = tv("Offline", 13f, pal.sub).apply { setPadding(0, dp(8), 0, 0) }
        header.addView(statusText)
        root.addView(header)

        // People nearby
        val body = ScrollView(this)
        val bodyCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(10)) }
        body.addView(bodyCol)
        bodyCol.addView(tv("PEOPLE NEARBY", 12f, pal.sub, true).apply { letterSpacing = 0.04f }, lp(bottom = 8))
        val pc = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = round(pal.card, 16, pal.stroke); setPadding(dp(14), dp(6), dp(14), dp(6))
        }
        peopleList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        pc.addView(peopleList)
        bodyCol.addView(pc)

        // Chat
        bodyCol.addView(tv("CHAT", 12f, pal.sub, true).apply { letterSpacing = 0.04f }, lp(top = 18, bottom = 8))
        chatScroll = ScrollView(this).apply {
            background = round(pal.card, 16, pal.stroke); setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        chatBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        chatScroll.addView(chatBox)
        bodyCol.addView(chatScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(260)))
        root.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // Input bar
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(10)); setBackgroundColor(pal.card)
        }
        val fileBtn = tv("+", 24f, pal.blue, true).apply {
            gravity = Gravity.CENTER; background = round(pal.blueSoft, 22); foreground = ripple(22)
            setOnClickListener { pickFile() }
        }
        bar.addView(fileBtn, LinearLayout.LayoutParams(dp(44), dp(44)))
        input = EditText(this).apply {
            hint = "Message"; textSize = 15f; setTextColor(pal.text); setHintTextColor(pal.sub)
            background = round(pal.field, 22, pal.stroke); setPadding(dp(16), dp(10), dp(16), dp(10)); maxLines = 4
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        bar.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(8); marginEnd = dp(8) })
        val sendBtn = tv("Send", 15f, pal.onFill, true).apply {
            gravity = Gravity.CENTER; background = round(pal.green, 22); foreground = ripple(22)
            setPadding(dp(18), dp(12), dp(18), dp(12)); setOnClickListener { sendMsg() }
        }
        bar.addView(sendBtn)
        root.addView(bar)

        refreshPeople()
    }

    private fun toggle() {
        if (!started) {
            if (!hasPermissions()) { toast("Allow permissions first"); ensurePermissions(); return }
            val name = nameInput.text.toString().ifBlank { "My phone" }
            prefs().edit().putString("name", name).apply()
            router.start(name); started = true
            startBtn.text = "Go offline"; startBtn.background = round(pal.red, 14)
            statusText.text = "Online - looking for people nearby"
        } else {
            router.stop(); voice?.stop(); voice = null; started = false
            startBtn.text = "Go online"; startBtn.background = round(pal.green, 14)
            statusText.text = "Offline"; refreshPeople()
        }
    }

    // ---------- People ----------
    private fun refreshPeople() {
        peopleList.removeAllViews()
        val conn = router.connected
        val found = router.found
        if (conn.isEmpty() && found.isEmpty()) {
            peopleList.addView(tv(if (started) "Searching…" else "Go online to find people nearby.", 14f, pal.sub).apply {
                setPadding(0, dp(10), 0, dp(10))
            })
            return
        }
        for ((id, name) in conn) peopleRow(id, name, connected = true)
        for ((id, name) in found) if (!conn.containsKey(id)) peopleRow(id, name, connected = false)
    }

    private fun peopleRow(id: String, name: String, connected: Boolean) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, dp(10)) }
        val dot = View(this).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(if (connected) pal.green else pal.sub) } }
        row.addView(dot, LinearLayout.LayoutParams(dp(10), dp(10)).apply { marginEnd = dp(10) })
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(tv(name, 15f, pal.text, true))
        col.addView(tv(if (connected) "Connected" else "Tap to connect", 12f, pal.sub))
        row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (connected) {
            row.addView(tv("Call", 14f, pal.blue, true).apply {
                background = round(pal.blueSoft, 10); setPadding(dp(14), dp(8), dp(14), dp(8)); foreground = ripple(10)
                setOnClickListener { startCall() }
            })
        } else {
            row.setOnClickListener { router.connect(id); statusText.text = "Connecting to $name…" }
        }
        peopleList.addView(row)
    }

    // ---------- Chat ----------
    private fun bubble(text: String, mine: Boolean, sender: String? = null, hops: Int = 0) {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = if (mine) Gravity.END else Gravity.START }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = round(if (mine) pal.bubble else pal.field, 14, pal.stroke)
            setPadding(dp(12), dp(7), dp(12), dp(7))
        }
        if (sender != null) col.addView(tv(sender + if (hops > 1) "  · via $hops hops" else "", 12f, pal.green, true))
        col.addView(tv(text, 15f, pal.text))
        val b = col
        val lpB = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(4); bottomMargin = dp(4); marginStart = if (mine) dp(50) else 0; marginEnd = if (mine) 0 else dp(50)
        }
        wrap.addView(b, lpB)
        chatBox.addView(wrap)
        handler.post { chatScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun sendMsg() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        if (router.connected.isEmpty()) { toast("Connect to someone first"); return }
        router.sendText(t); bubble(t, mine = true); input.setText("")
    }

    private fun pickFile() {
        if (router.connected.isEmpty()) { toast("Connect to someone first"); return }
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
        try { startActivityForResult(i, PICK_FILE) } catch (_: Exception) { toast("No file picker found") }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_FILE && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            var name = "file"; var size = 0L
            try {
                contentResolver.query(uri, null, null, null, null)?.use { cr ->
                    val ni = cr.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val si = cr.getColumnIndex(OpenableColumns.SIZE)
                    if (cr.moveToFirst()) { if (ni >= 0) name = cr.getString(ni); if (si >= 0) size = cr.getLong(si) }
                }
            } catch (_: Exception) {}
            router.sendFile(uri, name, size)
            bubble("📎 Sending $name", mine = true)
        }
    }

    // ---------- Call ----------
    private fun startCall() {
        if (router.connected.isEmpty()) { toast("Connect first"); return }
        if (voice == null) voice = VoiceCall(router)
        voice?.start()
        statusText.text = "In call — speak now"
        toast("Call started. Tap Go offline to end.")
    }

    // ---------- Router.UiListener ----------
    override fun onPeople() { handler.post { refreshPeople() } }
    override fun onMessage(fromName: String, body: String, hops: Int, mine: Boolean) {
        handler.post { bubble(body, mine = false, sender = fromName, hops = hops) }
    }
    override fun onFileStart(name: String, size: Long) { handler.post { bubble("📎 Receiving $name (${size / 1024} KB)…", mine = false) } }
    override fun onFileDone() { handler.post { bubble("✓ File received", mine = false) } }
    override fun onStream(payload: Payload) {
        handler.post { if (voice == null) voice = VoiceCall(router); voice?.playIncoming(payload); statusText.text = "Incoming call audio…" }
    }
    override fun onStatus(msg: String) { handler.post { statusText.text = msg } }

    // ---------- Permissions ----------
    private fun neededPermissions(): Array<String> {
        val l = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            l += Manifest.permission.BLUETOOTH_ADVERTISE; l += Manifest.permission.BLUETOOTH_CONNECT; l += Manifest.permission.BLUETOOTH_SCAN
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) l += Manifest.permission.NEARBY_WIFI_DEVICES
        return l.toTypedArray()
    }
    private fun hasPermissions() = neededPermissions().all { ContextCompat.checkSelfPermission(this, it) == android.content.pm.PackageManager.PERMISSION_GRANTED }
    private fun ensurePermissions() { if (!hasPermissions()) ActivityCompat.requestPermissions(this, neededPermissions(), 1) }
}
