package com.irfan.rabta

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import com.google.android.gms.nearby.connection.Payload
import java.io.InputStream
import java.io.PipedInputStream
import java.io.PipedOutputStream

/**
 * Simple voice call: mic audio is streamed to the other phone and played back.
 * Experimental - quality depends on the Wi-Fi Direct upgrade kicking in.
 */
class VoiceCall(private val mesh: Router) {
    private val sampleRate = 16000
    private val minBuf = AudioRecord.getMinBufferSize(
        sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
    ).coerceAtLeast(2048)

    private var record: AudioRecord? = null
    private var track: AudioTrack? = null
    private var sendThread: Thread? = null
    @Volatile private var running = false

    @SuppressLint("MissingPermission")
    fun start() {
        if (running) return
        running = true
        // Capture mic -> pipe -> Nearby STREAM payload
        val pipeOut = PipedOutputStream()
        val pipeIn = PipedInputStream(pipeOut, minBuf * 4)
        mesh.sendStream(Payload.fromStream(pipeIn))

        record = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION, sampleRate,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, minBuf
        )
        track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder()
                .setSampleRate(sampleRate)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(minBuf).build()

        record?.startRecording()
        track?.play()
        sendThread = Thread {
            val buf = ByteArray(minBuf)
            try {
                while (running) {
                    val n = record?.read(buf, 0, buf.size) ?: -1
                    if (n > 0) pipeOut.write(buf, 0, n)
                }
            } catch (_: Exception) {} finally { try { pipeOut.close() } catch (_: Exception) {} }
        }.also { it.start() }
    }

    /** Called when the other phone's audio stream arrives. */
    fun playIncoming(payload: Payload) {
        val input: InputStream = payload.asStream()?.asInputStream() ?: return
        ensurePlayback()
        Thread {
            val buf = ByteArray(minBuf)
            try {
                while (running) {
                    val n = input.read(buf)
                    if (n < 0) break
                    track?.write(buf, 0, n)
                }
            } catch (_: Exception) {}
        }.start()
    }

    @SuppressLint("MissingPermission")
    private fun ensurePlayback() {
        if (track == null) {
            track = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setAudioFormat(AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(minBuf).build()
            track?.play()
        }
        running = true
    }

    fun stop() {
        running = false
        try { sendThread?.join(300) } catch (_: Exception) {}
        try { record?.stop(); record?.release() } catch (_: Exception) {}
        try { track?.stop(); track?.release() } catch (_: Exception) {}
        record = null; track = null
    }
}
