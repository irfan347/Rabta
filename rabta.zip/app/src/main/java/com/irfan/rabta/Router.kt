package com.irfan.rabta

import android.content.Context
import com.google.android.gms.nearby.connection.Payload
import org.json.JSONObject
import java.security.SecureRandom

/**
 * The mesh brain. Sits on top of Mesh (transport) and adds what other offline
 * chat apps don't do well:
 *
 *  - Multi-hop: a message you send is re-broadcast by every phone that receives it,
 *    so it travels far beyond your own Bluetooth range (hop by hop).
 *  - Carry-delivery: messages are held in memory and handed to NEW phones the moment
 *    they connect - so a message reaches someone who wasn't even nearby when it was sent.
 *    People walking around physically carry messages to each other.
 *  - De-duplication: every message has an id; a phone processes each id once, so
 *    messages don't loop forever in the mesh.
 *
 * Envelope (compact JSON):
 *   i = id, f = from userId, n = from name, h = hops left, s = sent time(ms), b = body
 *   (v1: all chat is broadcast to the local mesh; direct 1-to-1 addressing comes next)
 */
class Router(ctx: Context, private val ui: UiListener) : Mesh.Listener {

    interface UiListener {
        fun onPeople()
        fun onMessage(fromName: String, body: String, hops: Int, mine: Boolean)
        fun onFileStart(name: String, size: Long)
        fun onFileDone()
        fun onStream(payload: Payload)
        fun onStatus(msg: String)
    }

    companion object {
        private const val START_HOPS = 8          // how far a message can travel
        private const val MAX_STORE = 500         // carry-delivery buffer size
        private const val MAX_SEEN = 3000
        private const val EXPIRY_MS = 24 * 3600 * 1000L
    }

    private val mesh = Mesh(ctx, this)
    private val prefs = ctx.getSharedPreferences("rabta", Context.MODE_PRIVATE)
    val myId: String = prefs.getString("userId", null) ?: run {
        val id = ByteArray(5).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02X".format(it) }
        prefs.edit().putString("userId", id).apply(); id
    }
    private var myName = "My phone"

    private val seen = object : LinkedHashMap<String, Boolean>(16, 0.75f, false) {
        override fun removeEldestEntry(e: Map.Entry<String, Boolean>?) = size > MAX_SEEN
    }
    private val store = LinkedHashMap<String, String>()  // id -> envelope json (for carry-delivery)
    val found = LinkedHashMap<String, String>()          // discovered, not-yet-connected endpoints

    val connected get() = mesh.connected

    fun start(name: String) { myName = name.ifBlank { "My phone" }; mesh.start(myName, myId) }
    fun stop() = mesh.stop()
    fun connect(endpointId: String) = mesh.connect(endpointId)
    fun sendFile(uri: android.net.Uri, name: String, size: Long) = mesh.sendFile(uri, name, size)
    fun sendStream(p: Payload) = mesh.sendStream(p)

    // ---------- send a chat message into the mesh ----------
    fun sendText(body: String) {
        val id = myId + "-" + System.currentTimeMillis().toString(36) + "-" +
            (SecureRandom().nextInt(0xFFFF)).toString(16)
        val env = JSONObject()
            .put("i", id).put("f", myId).put("n", myName)
            .put("h", START_HOPS).put("s", System.currentTimeMillis()).put("b", body)
            .toString()
        seen[id] = true
        remember(id, env)
        mesh.sendEnvelopeToAll(env)
    }

    // ---------- receive from the transport ----------
    override fun onEnvelope(endpointId: String, json: String) {
        val o = try { JSONObject(json) } catch (_: Exception) { return }
        val id = o.optString("i"); if (id.isEmpty() || seen.containsKey(id)) return
        seen[id] = true

        val from = o.optString("f")
        if (from == myId) return                       // my own message echoed back
        val hopsLeft = o.optInt("h", 0)
        val body = o.optString("b")
        val name = o.optString("n", "Someone")
        val sentHops = START_HOPS - hopsLeft + 1

        ui.onMessage(name, body, sentHops, mine = false)   // deliver to the user

        // forward onward (one less hop), and keep a copy to carry to future peers
        if (hopsLeft > 1) {
            val fwd = JSONObject(json).put("h", hopsLeft - 1).toString()
            remember(id, fwd)
            mesh.sendEnvelopeToAll(fwd, exceptEndpoint = endpointId)
        } else {
            remember(id, json)
        }
    }

    // when a new phone connects, hand it everything we're carrying (carry-delivery)
    override fun onConnected(endpointId: String, userId: String, name: String) {
        found.remove(endpointId)
        ui.onStatus("Connected to $name")
        ui.onPeople()
        val now = System.currentTimeMillis()
        synchronized(store) {
            val it = store.entries.iterator()
            while (it.hasNext()) {
                val e = it.next()
                val ts = try { JSONObject(e.value).optLong("s") } catch (_: Exception) { 0L }
                if (now - ts > EXPIRY_MS) { it.remove(); continue }
                mesh.sendEnvelopeTo(endpointId, e.value)
            }
        }
    }

    private fun remember(id: String, env: String) {
        synchronized(store) {
            store[id] = env
            while (store.size > MAX_STORE) store.remove(store.keys.first())
        }
    }

    // ---------- pass-throughs ----------
    override fun onFound(endpointId: String, name: String) { found[endpointId] = name; ui.onPeople() }
    override fun onLost(endpointId: String) { found.remove(endpointId); ui.onPeople() }
    override fun onConnecting(endpointId: String, name: String) = ui.onStatus("Connecting to $name…")
    override fun onDisconnected(endpointId: String) { ui.onStatus("Someone disconnected"); ui.onPeople() }
    override fun onFileStart(endpointId: String, payloadId: Long, name: String, size: Long) = ui.onFileStart(name, size)
    override fun onFileDone(endpointId: String, payloadId: Long) = ui.onFileDone()
    override fun onStream(endpointId: String, payload: Payload) = ui.onStream(payload)
    override fun onStatus(msg: String) = ui.onStatus(msg)

}
